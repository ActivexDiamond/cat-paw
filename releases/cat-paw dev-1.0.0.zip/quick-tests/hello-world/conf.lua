function love.conf(t)
	t.identity = "cat-paw-test-hello-world"
	t.window.title = "CatPaw - Test - Hello World"
	t.window.width = 1080
	t.window.height = 600
end
