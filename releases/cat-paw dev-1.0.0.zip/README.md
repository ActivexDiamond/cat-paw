# CatPaw
A 2D game development engine written on top of Love2D offering 3 different levels of abstraction that aims to offer facilities while not binding the user into any architecture.
