local middleclass = require "cat-paw.core.patterns.oop.middleclass"

------------------------------ Helpers ------------------------------

------------------------------ Constructor ------------------------------
local GameObject = middleclass("GameObject")
function GameObject:initialize()
end

------------------------------ Core API ------------------------------

------------------------------ API ------------------------------

------------------------------ Getters / Setters ------------------------------

return GameObject