local middleclass = require "cat-paw.core.patterns.oop.middleclass"

------------------------------ Helpers ------------------------------

------------------------------ Constructor ------------------------------
local Component = middleclass("Component")
function Component:initialize()
end

------------------------------ Core API ------------------------------

------------------------------ API ------------------------------

------------------------------ Getters / Setters ------------------------------

return Component