local uTable = {}

--- @function [parent=#core.utility.uTable] copy
-- @
function uTable.copy(t)
	error "WIP"
end

function uTable.deepCopy(t)
	error "WIP"
end

function uTable.copy()
	error "WIP"
end

function uTable.copy()
	error "WIP"
end
return uTable