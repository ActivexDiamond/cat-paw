local middleclass = require "cat-paw.core.patterns.oop.middleclass"

initialize()